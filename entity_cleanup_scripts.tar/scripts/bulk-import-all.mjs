/**
 * scripts/bulk-import-all.mjs
 * ULTRA-FAST bulk import of ALL tech sources from ALL-MALL.
 * Uses createMany with chunking for 100x speed improvement.
 * Handles all 9 sources including Pacmax with -7% pricing.
 *
 * Usage: node scripts/bulk-import-all.mjs
 */

import { PrismaClient } from '@prisma/client';
import { readFileSync, existsSync } from 'fs';

const prisma = new PrismaClient();

const CATEGORY_MAP = {
  "Phones": "smartphones", "Smartphones & Tablets": "smartphones", "Phone Accessories": "smartphones",
  "Laptops": "laptops", "Laptops & Computers": "laptops", "Laptop Batteries & Chargers": "laptops",
  "Business Laptops": "laptops", "Gaming Laptops": "laptops", "Laptop Accessories": "laptops",
  "Tablets": "tablets", "Ipads & Tablets": "tablets",
  "Gaming": "gaming", "Gaming & Consoles": "gaming", "Gaming Consoles": "gaming",
  "Gaming Peripherals": "gaming", "Gaming Furniture": "gaming",
  "Audio": "audio", "Speakers & Sound": "audio",
  "Accessories": "accessories", "Mice": "accessories", "Keyboards": "accessories",
  "Webcams": "accessories", "Bags & Luggage": "accessories", "Monitors": "accessories",
  "TVs": "accessories", "TVs & Smart Panels": "accessories", "TV & Displays": "accessories",
  "TV Stands & Mounts": "accessories", "Projectors": "accessories",
  "Desktops & PCs": "accessories", "Desktop & PCs": "accessories", "Desktops": "accessories",
  "PC Cases": "accessories", "PC Components & Cooling": "accessories", "PC Cooling": "accessories",
  "Power Supplies": "accessories", "Processors": "accessories", "Motherboards": "accessories",
  "Graphics Cards": "accessories", "UPS & Power": "accessories", "Software": "accessories",
  "Office Supplies": "accessories", "Tools & Hardware": "accessories",
  "Electronic Components": "accessories", "Computer Parts": "accessories",
  "Peripherals": "accessories", "Computer Accessories": "accessories",
  "Internal Storage": "accessories", "RAM": "accessories", "Memory (RAM)": "storage",
  "Adapters": "accessories", "Chargers & Cables": "accessories",
  "Cables": "accessories", "Memory Cards & Accessories": "accessories",
  "Camera Gimbals": "cameras", "Lighting & Studio": "accessories",
  "All Content Creator Accessories": "accessories",
  "Networking": "networking", "Communications & Accessories": "networking",
  "Networking & PBX": "networking",
  "Cameras": "cameras", "Cameras & Photography": "cameras", "Cameras & Surveillance": "cameras",
  "Cameras & Lenses": "cameras",
  "Printers": "printers", "Printers & Scanners": "printers", "Printers and Scanners": "printers",
  "Smart Home & IoT": "smart-home", "Smart Security": "smart-home",
  "Storage": "storage", "Storage & Accessories": "storage", "External Storage": "storage",
  "Wearables": "wearables", "Watches & Jewelry": "wearables", "WATCHES": "wearables",
  "Access Control": "smart-home", "Decor & Lighting": "accessories", "POS & Peripherals": "accessories",
  "Stylus": "accessories", "Drawing Pads": "accessories",
  "Headsets": "audio", "Headphones": "audio",
  "Christmas": "accessories", "Combo": "accessories",
  "Apple Accessories": "accessories",
  "CPU Coolers": "accessories", "Inkjet Cartridges": "printers",
};

function classifyByStrictKeywords(item) {
  const title = (item?.title || '').toLowerCase();
  const srcSlug = (item?.slug || '').toLowerCase();
  const sourceUrl = (item?.sourceUrl || '').toLowerCase();
  const haystack = `${title} ${srcSlug} ${sourceUrl}`;

  const has = (re) => re.test(haystack);

  if (has(/\b(ipad|tablet|galaxy tab|tab s\d|tab a\d?)\b/i)) return 'tablets';

  const hasPhoneAccessory = /(phone case|screen protector|phone holder)/i.test(haystack);
  const hasLandlineClues = /\b(corded|cordless|landline|desk phone)\b/i.test(haystack);
  if (
    has(/\b(iphone|smartphone|galaxy s\d|redmi|xiaomi|pixel)\b/i) ||
    (hasPhoneAccessory && !hasLandlineClues)
  ) {
    return 'smartphones';
  }

  if (has(/\b(laptop|notebook|macbook|thinkpad|ideapad|vivobook|chromebook)\b/i)) return 'laptops';
  if (has(/\b(ps5|ps4|playstation|xbox|nintendo|switch oled|gamepad|joystick|gaming mouse|gaming keyboard|gaming headset)\b/i)) return 'gaming';
  if (has(/\b(headphone|headset|earbud|earphone|airpods|speaker|microphone|podcast mic|soundbar)\b/i)) return 'audio';
  if (has(/\b(router|modem|wi-?fi|access point|mesh|ethernet|cat6|rj45|network switch|poe switch|gigabit switch)\b/i)) return 'networking';
  if (has(/\b(webcam|cctv|camera lens|tripod|dvr|nvr|gopro)\b/i)) return 'cameras';
  if (has(/\b(printer|toner|cartridge|inkjet|laserjet|scanner|drum unit)\b/i)) return 'printers';
  if (has(/\b(smart lock|smart bulb|video doorbell|smart sensor|home automation)\b/i)) return 'smart-home';
  if (has(/\b(ssd|hdd|nvme|flash drive|usb drive|micro sd|sd card|memory card|ddr3|ddr4|ddr5|ram memory|external hard|hard disk)\b/i)) return 'storage';
  if (has(/\b(smartwatch|smart watch|fitbit|garmin watch|apple watch|mi band)\b/i)) return 'wearables';

  return null;
}

function resolveCategorySlug(item) {
  const mapped = CATEGORY_MAP[item?.category];
  const strict = classifyByStrictKeywords(item);

  if (mapped && mapped !== 'accessories') return mapped;
  if (strict) return strict;
  return mapped || null;
}

function slugify(text) {
  if (!text) return 'product';
  return text.toLowerCase().replace(/[^\w\s-]/g, '').replace(/\s+/g, '-').replace(/-+/g, '-').replace(/^-+|-+$/g, '').substring(0, 80) || 'product';
}

function decodeHtmlEntities(text) {
  return (text || '')
    .replace(/&#(\d+);/g, (_, code) => String.fromCodePoint(parseInt(code, 10)))
    .replace(/&#x([\da-f]+);/gi, (_, code) => String.fromCodePoint(parseInt(code, 16)))
    .replace(/&(amp|lt|gt|quot|apos|nbsp);/gi, (_, entity) => {
      switch (entity.toLowerCase()) {
        case 'amp': return '&';
        case 'lt': return '<';
        case 'gt': return '>';
        case 'quot': return '"';
        case 'apos': return "'";
        case 'nbsp': return ' ';
        default: return '';
      }
    });
}

function stripHtml(html) {
  return decodeHtmlEntities(html || '').replace(/<[^>]*>/g, '').replace(/\s+/g, ' ').trim().substring(0, 2000);
}

function upgradeImageUrl(url) {
  if (!url || typeof url !== 'string') return url;
  url = url.replace(/\/stencil\/\d+x\d+\//i, '/stencil/original/');
  url = url.replace(/-\d+x\d+(\.(jpe?g|png|webp|gif|avif))$/i, '$1');
  url = url.replace(/[?&]c=\d+/g, '');
  return url;
}

function parseImageUrls(raw) {
  try {
    const parsed = typeof raw === 'string' ? JSON.parse(raw) : raw;
    return Array.isArray(parsed) ? parsed.filter(Boolean).slice(0, 10).map(upgradeImageUrl) : [];
  } catch { return []; }
}

const KNOWN_BRANDS = [
  'Apple', 'Samsung', 'Sony', 'HP', 'Dell', 'Lenovo', 'ASUS', 'Acer', 'MSI',
  'Logitech', 'JBL', 'Canon', 'Epson', 'TP-Link', 'D-Link', 'NETGEAR',
  'Intel', 'AMD', 'NVIDIA', 'Corsair', 'Kingston', 'Seagate', 'WD',
  'Beats', 'Bose', 'Sennheiser', 'Razer', 'SteelSeries', 'HyperX',
  'Anker', 'Belkin', 'UGREEN', 'Xiaomi', 'Huawei', 'Google', 'Microsoft',
  'Nintendo', 'PlayStation', 'Xbox', 'DJI', 'GoPro', 'Philips', 'Panasonic',
  'LG', 'Toshiba', 'Hikvision', 'Garmin', 'Fitbit',
];

function extractBrand(title, brand) {
  if (brand && brand !== 'No Brand' && brand !== 'Unknown') return brand.trim();
  const upper = title.toUpperCase();
  for (const b of KNOWN_BRANDS) { if (upper.includes(b.toUpperCase())) return b; }
  return brand || null;
}

function calcPrice(sourcePrice, competitor) {
  if (!sourcePrice || sourcePrice <= 0) return 0;
  if (competitor.priceFormula) {
    try {
      const fn = new Function('source','cost','"use strict";return (' + competitor.priceFormula + ');');
      const r = fn(sourcePrice, sourcePrice);
      if (typeof r === 'number' && !isNaN(r) && r > 0) return Math.round(r * 100) / 100;
    } catch {}
  }
  return Math.round(sourcePrice * (1 + (competitor.markupPct||0)/100) * 100) / 100;
}

async function main() {
  console.log('='.repeat(47));
  console.log('  ULTRA-FAST BULK IMPORT - ALL TECH SOURCES');
  console.log('='.repeat(47));

  // 1. Load categories
  const allCats = await prisma.category.findMany();
  const catBySlug = {};
  for (const c of allCats) catBySlug[c.slug] = c;
  console.log('Categories:', allCats.length);

  // 2. Load competitors
  const allCompetitors = await prisma.competitor.findMany();
  const compByName = {};
  for (const c of allCompetitors) compByName[c.name.toLowerCase()] = c;
  console.log('Competitors:', allCompetitors.length);

  // 3. Pre-load existing data into Sets
  const existingSourceIds = new Set();
  const existingSlugs = new Set();
  const existingSkus = new Set();

  // Load in batches to avoid OOM
  let cursor = null;
  let hasMore = true;
  let loadedExisting = 0;
  while (hasMore) {
    const batch = await prisma.product.findMany({
      select: { id: true, slug: true, sku: true, sourceId: true },
      take: 5000,
      ...(cursor ? { skip: 1, cursor: { id: cursor } } : {}),
      orderBy: { id: 'asc' },
    });
    if (batch.length === 0) { hasMore = false; break; }
    cursor = batch[batch.length - 1].id;
    for (const p of batch) {
      if (p.sourceId) existingSourceIds.add(p.sourceId);
      if (p.slug) existingSlugs.add(p.slug);
      if (p.sku) existingSkus.add(p.sku);
    }
    loadedExisting += batch.length;
  }
  console.log('Existing products loaded:', loadedExisting);
  console.log('Existing sourceIds:', existingSourceIds.size);
  console.log('Existing slugs:', existingSlugs.size);

  // 4. Define all sources
  const SOURCES = [
    { file: '../ALL-MALL/all-mall-mvp/technodel-export-ayoub.json', name: 'Ayoub', prefix: 'AYB' },
    { file: '../ALL-MALL/all-mall-mvp/technodel-export-expert-zone.json', name: 'Expert-Zone (ezone)', prefix: 'EZN' },
    { file: '../ALL-MALL/all-mall-mvp/technodel-export-comparts.json', name: 'Comparts', prefix: 'CPT' },
    { file: '../ALL-MALL/all-mall-mvp/technodel-export-pacmax.json', name: 'Pacmax', prefix: 'PCX' },
    { file: '../ALL-MALL/all-mall-mvp/technodel-export-katranji.json', name: 'Katranji', prefix: 'KAT' },
    { file: '../ALL-MALL/all-mall-mvp/technodel-export-dslr-zone.json', name: 'Dslr-Zone', prefix: 'DSL' },
    { file: '../ALL-MALL/all-mall-mvp/technodel-export-mzone.json', name: 'MZone', prefix: 'MZN' },
    { file: '../ALL-MALL/all-mall-mvp/technodel-export-jimmy.json', name: 'Jimmy', prefix: 'JIM' },
    { file: '../ALL-MALL/all-mall-mvp/technodel-export-technodel.json', name: 'Technodel', prefix: 'TND' },
  ];

  let totalCreated = 0;
  let totalSkippedCat = 0;
  let totalSkippedDup = 0;
  let totalErrors = 0;

  for (const source of SOURCES) {
    if (!existsSync(source.file)) {
      console.log('\n  FILE NOT FOUND:', source.file);
      continue;
    }

    const raw = readFileSync(source.file, 'utf8');
    const data = JSON.parse(raw);
    const products = data.products || [];
    console.log('\n' + '-'.repeat(47));
    console.log('  ' + source.name + ' (' + source.prefix + '): ' + products.length + ' total');

    const competitor = compByName[source.name.toLowerCase()];

    // Process all products in memory first
    const records = [];
    let skippedCat = 0;
    let skippedDup = 0;

    for (const item of products) {
      try {
        if (!item.title || (!item.displayPrice && !item.sourcePrice)) { skippedCat++; continue; }
        const title = decodeHtmlEntities(item.title || '').replace(/\s+/g, ' ').trim().substring(0, 200);
        if (!title) { skippedCat++; continue; }

        // Skip if sourceId already exists
        if (item.sourceId && existingSourceIds.has(item.sourceId)) { skippedDup++; continue; }

        const targetSlug = resolveCategorySlug(item);
        if (!targetSlug) { skippedCat++; continue; }
        const category = catBySlug[targetSlug];
        if (!category) { skippedCat++; continue; }

        const images = parseImageUrls(item.imageUrls);
        const firstImage = images[0] || null;

        // Generate unique SKU
        const skuBase = source.prefix + '-' + (item.sourceId || '').replace(/[^a-zA-Z0-9]/g, '-').substring(0, 20);
        let sku = skuBase;
        let skuSuffix = 1;
        while (existingSkus.has(sku)) { sku = skuBase + '-' + (skuSuffix++); }
        existingSkus.add(sku);

        // Generate unique slug
        const baseSlug = slugify(title);
        let slug = baseSlug;
        let slugSuffix = 1;
        while (existingSlugs.has(slug)) { slug = baseSlug + '-' + (slugSuffix++); }
        existingSlugs.add(slug);

        // Price with competitor markup
        const sourcePrice = item.sourcePrice || item.displayPrice || 0;
        const displayPrice = (competitor && sourcePrice > 0)
          ? calcPrice(sourcePrice, competitor)
          : (item.displayPrice || sourcePrice || 0);

        const brand = extractBrand(title, item.brand);

        records.push({
          slug,
          sku,
          title,
          shortDescription: stripHtml(item.shortDescription || item.description || '').substring(0, 300),
          description: item.description || item.shortDescription || '',
          highlights: '[]',
          displayPrice: Math.round(displayPrice * 100) / 100,
          currency: item.currency || 'USD',
          images: JSON.stringify(images),
          categoryId: category.id,
          attributes: '{}',
          specs: '[]',
          brand,
          sourceId: item.sourceId || null,
          sourceUrl: item.sourceUrl || null,
          sourcePrice: Math.round(sourcePrice * 100) / 100,
          costPrice: Math.round(sourcePrice * 100) / 100,
          competitorId: competitor?.id || null,
          isVisible: true,
          isFeatured: false,
          isNew: true,
          stock: 999,
          ogImage: firstImage,
          seoTitle: title + ' - Technodel Lebanon',
        });

        if (item.sourceId) existingSourceIds.add(item.sourceId);
      } catch (err) { totalErrors++; }
    }

    console.log('  Prepared: ' + records.length + ' to insert, ' + skippedCat + ' skip(cat), ' + skippedDup + ' skip(dup)');

    // Bulk insert with createMany in chunks
    const CHUNK = 500;
    let created = 0;
    for (let i = 0; i < records.length; i += CHUNK) {
      const chunk = records.slice(i, i + CHUNK);
      try {
        const result = await prisma.product.createMany({ data: chunk, skipDuplicates: true });
        created += result.count;
      } catch (err) {
        // If createMany fails, try individual creates for this chunk
        for (const rec of chunk) {
          try {
            await prisma.product.create({ data: rec });
            created++;
          } catch { totalErrors++; }
        }
      }
      if (created % 1000 === 0) process.stdout.write('    ' + created + ' created...\r');
    }

    totalCreated += created;
    totalSkippedCat += skippedCat;
    totalSkippedDup += skippedDup;
    console.log('  RESULT: ' + created + ' created');
  }

  console.log('\n' + '='.repeat(47));
  console.log('  BULK IMPORT COMPLETE');
  console.log('  Created: ' + totalCreated);
  console.log('  Skipped(no-cat): ' + totalSkippedCat);
  console.log('  Skipped(dup): ' + totalSkippedDup);
  console.log('  Errors: ' + totalErrors);

  // Final count
  const finalCount = await prisma.product.count();
  console.log('  Total products now: ' + finalCount);
  console.log('='.repeat(47));

  await prisma.$disconnect();
}

main().catch(e => { console.error(e); process.exit(1); });

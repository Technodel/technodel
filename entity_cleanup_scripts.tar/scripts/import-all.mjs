/**
 * scripts/import-all.mjs
 * Bulk import products from ALL-MALL exported JSON files into Technodel.
 * Imports ayoub, ezone (Expert-Zone), comparts and existing Technodel data.
 *
 * Usage: node scripts/import-all.mjs
 */

import { PrismaClient } from '@prisma/client';
import { readFileSync, existsSync } from 'fs';

const prisma = new PrismaClient();

// ─── CATEGORY MAPPING ──────────────────────────────────────────────────────
// Maps source site categories to Technodel category slugs
const CATEGORY_MAP = {
  // Smartphones
  "Phones": "smartphones",
  "Smartphones & Tablets": "smartphones",
  "Phone Accessories": "smartphones",
  "Smartphones & Tablets": "smartphones",

  // Laptops
  "Laptops": "laptops",
  "Laptops & Computers": "laptops",
  "Laptop Batteries & Chargers": "laptops",

  // Tablets
  "Tablets": "tablets",

  // Gaming
  "Gaming": "gaming",
  "Gaming & Consoles": "gaming",
  "Gaming Consoles": "gaming",
  "Gaming Peripherals": "gaming",
  "Gaming Furniture": "gaming",

  // Audio
  "Audio": "audio",
  "Speakers & Sound": "audio",

  // Accessories (catch-all for misc)
  "Accessories": "accessories",
  "Mice": "accessories",
  "Keyboards": "accessories",
  "Webcams": "accessories",
  "Bags & Luggage": "accessories",
  "Monitors": "accessories",
  "TVs": "accessories",
  "TVs & Smart Panels": "accessories",
  "TV & Displays": "accessories",
  "TV Stands & Mounts": "accessories",
  "Projectors": "accessories",
  "Desktops & PCs": "accessories",
  "Desktops & PCs": "accessories",
  "Desktop & PCs": "accessories",
  "PC Cases": "accessories",
  "PC Components & Cooling": "accessories",
  "PC Cooling": "accessories",
  "Power Supplies": "accessories",
  "Processors": "accessories",
  "Motherboards": "accessories",
  "Graphics Cards": "accessories",
  "UPS & Power": "accessories",
  "Software": "accessories",
  "Office Supplies": "accessories",
  "Tools & Hardware": "accessories",
  // ─── NON-TECH CATEGORIES (EXCLUDED) ─────────────────────────────
  // Home appliances, toys, perfumes, beauty, furniture, clothing,
  // pet supplies, automotive, books, and other non-electronics items
  // are intentionally omitted so they default to skip below.

  // Networking
  "Networking": "networking",

  // Cameras
  "Cameras": "cameras",
  "Cameras & Photography": "cameras",
  "Cameras & Surveillance": "cameras",

  // Printers
  "Printers": "printers",
  "Printers & Scanners": "printers",

  // Smart Home
  "Smart Home & IoT": "smart-home",
  "Smart Security": "smart-home",

  // Storage
  "Storage": "storage",
  "Storage & Accessories": "storage",
  "External Storage": "storage",
  "Memory (RAM)": "storage",

  // Wearables
  "Wearables": "wearables",
  "Watches & Jewelry": "wearables",

  // Additional tech categories found in source exports
  "Electronic Components": "accessories",
  "TV & Displays": "accessories",
  "Access Control": "smart-home",
  "Decor & Lighting": "accessories",
  "POS & Peripherals": "accessories",

  // ─── NON-TECH CATEGORIES (EXPLICITLY SKIPPED) ───────────────────
  // These categories exist in source exports but are NOT computers/electronics.
  // They are intentionally omitted from the map so no key means skip.
  // Home: Home Appliances, Large Appliances, Kitchen Appliances, Kitchen & Dining, Lighting (decorative)
  // Furniture: Furniture, Seating & Chairs, Desks & Tables, Rugs & Carpets
  // Lifestyle: Toys & Games, Toys & Kids, Sports & Fitness, Sports & Outdoors, Garden & Outdoor
  // Personal: Perfumes & Fragrances, Beauty & Makeup, Hair Care, Skincare, Personal Care
  // Pets: Pet Supplies
  // Baby: Baby & Kids
  // Auto: Automotive
  // Books: Books & Media
  // Fashion: Shoes & Footwear
  // Health: Medical & Health, Bathroom & Organization
  // Other: General, Pending Review, Other / Uncategorized, New Arrivals
  // (No key = skipped via the null fallback below)
};

function classifyByStrictKeywords(item) {
  const title = (item?.title || '').toLowerCase();
  const srcSlug = (item?.slug || '').toLowerCase();
  const sourceUrl = (item?.sourceUrl || '').toLowerCase();
  const haystack = `${title} ${srcSlug} ${sourceUrl}`;

  const has = (re) => re.test(haystack);

  if (has(/\b(ipad|tablet|galaxy tab|tab s\d|tab a\d?)\b/i)) return 'tablets';

  const hasPhoneAccessory = /(phone case|screen protector|phone holder)/i.test(haystack);
  const hasLandlineClues = /\b(corded|cordless|landline|desk phone)\b/i.test(haystack);
  if (
    has(/\b(iphone|smartphone|galaxy s\d|redmi|xiaomi|pixel)\b/i) ||
    (hasPhoneAccessory && !hasLandlineClues)
  ) {
    return 'smartphones';
  }

  if (has(/\b(laptop|notebook|macbook|thinkpad|ideapad|vivobook|chromebook)\b/i)) return 'laptops';
  if (has(/\b(ps5|ps4|playstation|xbox|nintendo|switch oled|gamepad|joystick|gaming mouse|gaming keyboard|gaming headset)\b/i)) return 'gaming';
  if (has(/\b(headphone|headset|earbud|earphone|airpods|speaker|microphone|podcast mic|soundbar)\b/i)) return 'audio';
  if (has(/\b(router|modem|wi-?fi|access point|mesh|ethernet|cat6|rj45|network switch|poe switch|gigabit switch)\b/i)) return 'networking';
  if (has(/\b(webcam|cctv|camera lens|tripod|dvr|nvr|gopro)\b/i)) return 'cameras';
  if (has(/\b(printer|toner|cartridge|inkjet|laserjet|scanner|drum unit)\b/i)) return 'printers';
  if (has(/\b(smart lock|smart bulb|video doorbell|smart sensor|home automation)\b/i)) return 'smart-home';
  if (has(/\b(ssd|hdd|nvme|flash drive|usb drive|micro sd|sd card|memory card|ddr3|ddr4|ddr5|ram memory|external hard|hard disk)\b/i)) return 'storage';
  if (has(/\b(smartwatch|smart watch|fitbit|garmin watch|apple watch|mi band)\b/i)) return 'wearables';

  return null;
}

function resolveCategorySlug(item) {
  const mapped = CATEGORY_MAP[item?.category];
  const strict = classifyByStrictKeywords(item);

  // Keep strong explicit mappings unless they are generic accessories.
  if (mapped && mapped !== 'accessories') return mapped;

  // Upgrade generic accessories (or missing map) to stricter category when possible.
  if (strict) return strict;

  return mapped || null;
}

// ─── HELPERS ───────────────────────────────────────────────────────────────

function slugify(text) {
  if (!text) return 'product';
  return text
    .toLowerCase()
    .replace(/[^\w\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-+|-+$/g, '')
    .substring(0, 80) || 'product';
}

function decodeHtmlEntities(text) {
  return (text || '')
    .replace(/&#(\d+);/g, (_, code) => String.fromCodePoint(parseInt(code, 10)))
    .replace(/&#x([\da-f]+);/gi, (_, code) => String.fromCodePoint(parseInt(code, 16)))
    .replace(/&(amp|lt|gt|quot|apos|nbsp);/gi, (_, entity) => {
      switch (entity.toLowerCase()) {
        case 'amp': return '&';
        case 'lt': return '<';
        case 'gt': return '>';
        case 'quot': return '"';
        case 'apos': return "'";
        case 'nbsp': return ' ';
        default: return '';
      }
    });
}

function stripHtml(html) {
  return decodeHtmlEntities(html || '')
    .replace(/<[^>]*>/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .substring(0, 2000);
}

/**
 * Upgrade image URL to highest resolution available.
 * Handles BigCommerce CDN thumbnails, WooCommerce-sized images.
 */
function upgradeImageUrl(url) {
  if (!url || typeof url !== 'string') return url;
  // BigCommerce: /stencil/100x100/ → /stencil/original/
  // Also handles 128x128, 200x200, 300x300, 640x640 etc.
  url = url.replace(/\/stencil\/\d+x\d+\//i, '/stencil/original/');
  // WooCommerce: -300x300.jpg → .jpg (any size suffix)
  url = url.replace(/-\d+x\d+(\.(jpe?g|png|webp|gif|avif))$/i, '$1');
  // BigCommerce size query params: ?c=2 → remove (keep other params for CDN)
  url = url.replace(/[?&]c=\d+/g, '');
  return url;
}

function parseImageUrls(raw) {
  try {
    const parsed = typeof raw === 'string' ? JSON.parse(raw) : raw;
    const urls = Array.isArray(parsed) ? parsed.filter(Boolean).slice(0, 10) : [];
    return urls.map(upgradeImageUrl);
  } catch {
    return [];
  }
}

function extractBrand(title, brand) {
  if (brand && brand !== 'No Brand' && brand !== 'Unknown') return brand.trim();
  // Try to extract brand from title
  const knownBrands = [
    'Apple', 'Samsung', 'Sony', 'HP', 'Dell', 'Lenovo', 'ASUS', 'Acer', 'MSI',
    'Logitech', 'JBL', 'Canon', 'Epson', 'TP-Link', 'D-Link', 'NETGEAR',
    'Intel', 'AMD', 'NVIDIA', 'Corsair', 'Kingston', 'Seagate', 'WD',
    'Beats', 'Bose', 'Sennheiser', 'Razer', 'SteelSeries', 'HyperX',
    'Anker', 'Belkin', 'UGREEN', 'Xiaomi', 'Huawei', 'Google', 'Microsoft',
    'Nintendo', 'PlayStation', 'Xbox', 'DJI', 'GoPro', 'Philips', 'Panasonic',
    'LG', 'Toshiba', 'Hikvision', 'Garmin', 'Fitbit',
  ];
  const upper = title.toUpperCase();
  for (const b of knownBrands) {
    if (upper.includes(b.toUpperCase())) return b;
  }
  return brand || null;
}

/**
 * Apply competitor pricing formula.
 * If competitor has priceFormula (JS expression), evaluate it with source.
 * Otherwise apply markupPct as percentage.
 */
function applyCompetitorPricing(sourcePrice, competitor) {
  if (!sourcePrice || sourcePrice <= 0) return 0;
  if (competitor.priceFormula) {
    try {
      const fn = new Function(
        "source", "cost",
        `"use strict"; return (${competitor.priceFormula});`
      );
      const result = fn(sourcePrice, sourcePrice);
      if (typeof result === "number" && !isNaN(result) && result > 0)
        return Math.round(result * 100) / 100;
    } catch {
      // fall through to percentage
    }
  }
  // Default: markupPct as percentage
  const pct = competitor.markupPct || 0;
  return Math.round(sourcePrice * (1 + pct / 100) * 100) / 100;
}

// ─── MAIN ──────────────────────────────────────────────────────────────────

try {
  // Load categories
  const allCats = await prisma.category.findMany();
  const catBySlug = {};
  for (const c of allCats) catBySlug[c.slug] = c;
  console.log(`Loaded ${allCats.length} Technodel categories`);

  // Source files to import — all tech sources from ALL-MALL
  const sources = [
    { file: '../ALL-MALL/all-mall-mvp/technodel-export-ayoub.json', name: 'Ayoub' },
    { file: '../ALL-MALL/all-mall-mvp/technodel-export-expert-zone.json', name: 'Expert-Zone (ezone)' },
    { file: '../ALL-MALL/all-mall-mvp/technodel-export-comparts.json', name: 'Comparts' },
    { file: '../ALL-MALL/all-mall-mvp/technodel-export-pacmax.json', name: 'Pacmax' },
    { file: '../ALL-MALL/all-mall-mvp/technodel-export-katranji.json', name: 'Katranji' },
    { file: '../ALL-MALL/all-mall-mvp/technodel-export-dslr-zone.json', name: 'Dslr-Zone' },
    { file: '../ALL-MALL/all-mall-mvp/technodel-export-mzone.json', name: 'MZone' },
    { file: '../ALL-MALL/all-mall-mvp/technodel-export-jimmy.json', name: 'Jimmy' },
    { file: '../ALL-MALL/all-mall-mvp/technodel-export-technodel.json', name: 'Technodel' },
  ];

  // Clean all existing products first (to remove any duplicates from previous runs)
  console.log('Cleaning existing products...');
  await prisma.product.deleteMany({});
  console.log('All existing products deleted.\n');

  let totalImported = 0;
  let totalSkipped = 0;
  let totalErrors = 0;

  for (const source of sources) {
    if (!existsSync(source.file)) {
      console.log(`\n⚠ File not found: ${source.file}`);
      continue;
    }

    const raw = readFileSync(source.file, 'utf8');
    const data = JSON.parse(raw);
    const products = data.products || [];
    console.log(`\n══════════════════════════════════════════════`);
    console.log(`📦 ${source.name}: ${products.length} products`);
    console.log(`══════════════════════════════════════════════`);

    let imported = 0, skipped = 0, errors = 0;

    for (const item of products) {
      try {
        // Validate
        if (!item.title || (!item.displayPrice && !item.sourcePrice)) {
          skipped++;
          continue;
        }

        const title = decodeHtmlEntities(item.title || '').replace(/\s+/g, ' ').trim().substring(0, 200);
        if (!title) { skipped++; continue; }

        // Map category — only explicitly mapped tech categories are imported
        const targetSlug = resolveCategorySlug(item);
        if (!targetSlug) { skipped++; continue; }
        const category = catBySlug[targetSlug];
        if (!category) { skipped++; continue; }

        // Parse images
        const images = parseImageUrls(item.imageUrls);
        const firstImage = images[0] || null;

        // Generate slug
        const baseSlug = slugify(title);
        let slug = baseSlug;

        // Generate SKU with source prefix
        const sourcePrefix = source.name === 'Ayoub' ? 'AYB'
          : source.name.includes('Expert') ? 'EZN'
          : source.name === 'Comparts' ? 'CPT'
          : source.name === 'Pacmax' ? 'PCX'
          : source.name === 'Katranji' ? 'KAT'
          : source.name === 'Dslr-Zone' ? 'DSL'
          : source.name === 'MZone' ? 'MZN'
          : source.name === 'Jimmy' ? 'JIM'
          : source.name === 'Technodel' ? 'TND'
          : 'GEN';
        const skuBase = `${sourcePrefix}-${(item.sourceId || '').replace(/[^a-zA-Z0-9]/g, '-').substring(0, 20)}`;
        let sku = skuBase;

        // Resolve duplicate slugs
        let slugSuffix = 1;
        while (await prisma.product.findUnique({ where: { slug } })) {
          slug = `${baseSlug}-${slugSuffix++}`;
        }

        // Resolve duplicate SKUs
        let skuSuffix = 1;
        let finalSku = sku;
        while (await prisma.product.findUnique({ where: { sku: finalSku } })) {
          finalSku = `${sku}-${skuSuffix++}`;
        }

        // Check if already imported by sourceId (prevents duplicates on re-run)
        if (item.sourceId) {
          const existing = await prisma.product.findFirst({ where: { sourceId: item.sourceId } });
          if (existing) {
            skipped++;
            continue;
          }
        }

        // Determine price with competitor markup
        const sourcePrice = item.sourcePrice || item.displayPrice || 0;
        // Resolve competitor for pricing formula
        const competitorName = source.name;
        let competitorRecord = null;
        if (competitorName) {
          competitorRecord = await prisma.competitor.findFirst({
            where: { name: { contains: competitorName.replace('-', ' ') } },
          });
        }
        let displayPrice = sourcePrice;
        if (competitorRecord && sourcePrice > 0) {
          displayPrice = applyCompetitorPricing(sourcePrice, competitorRecord);
        } else {
          displayPrice = item.displayPrice || sourcePrice || 0;
        }

        // Extract brand
        const brand = extractBrand(title, item.brand);

        // Create product
        await prisma.product.create({
          data: {
            slug,
            sku: finalSku,
            title,
            shortDescription: stripHtml(item.shortDescription || item.description || '').substring(0, 300),
            description: item.description || item.shortDescription || '',
            highlights: '[]',
            displayPrice: Math.round(displayPrice * 100) / 100,
            currency: item.currency || 'USD',
            images: JSON.stringify(images),
            categoryId: category.id,
            attributes: '{}',
            specs: '[]',
            brand,
            sourceId: item.sourceId || null,
            sourceUrl: item.sourceUrl || null,
            sourcePrice: Math.round(sourcePrice * 100) / 100,
            costPrice: Math.round(sourcePrice * 100) / 100,
            competitorId: competitorRecord?.id || null,
            isVisible: true,
            isFeatured: item.isFeatured === 1 || item.isFeatured === true,
            isNew: true,
            stock: 999,
            ogImage: firstImage,
            seoTitle: `${title} - Technodel Lebanon`,
          },
        });

        imported++;
        totalImported++;

        // Progress indicator
        if (imported % 100 === 0) {
          process.stdout.write(`  ✓ ${imported} imported...\r`);
        }
      } catch (err) {
        errors++;
        totalErrors++;
      }
    }

    console.log(`  ✓ ${source.name}: ${imported} imported, ${skipped} skipped, ${errors} errors`);
  }

  console.log(`\n══════════════════════════════════════════════`);
  console.log(`🎉 IMPORT COMPLETE`);
  console.log(`   Total imported: ${totalImported}`);
  console.log(`   Total errors:   ${totalErrors}`);
  console.log(`══════════════════════════════════════════════`);

} catch (err) {
  console.error('Import failed:', err);
  process.exit(1);
} finally {
  process.exit(0);
}
